#!/bin/bash

if [ "$#" -eq 0 ]
then
 DIR="./"
else
 DIR="$1"
fi

for j in {1..20}; do
 echo "Check results for $DIR${j}_to1.test";
 for i in {1..20}; do
  awk 'c&&!--c;/steffe'$i'/{c=7}' $DIR/$j"_to1.test" | awk -F " " '{s+=$8}; END {printf "%d\n",s/100}' | 
  tee >&1 >(cat >> $DIR/CaPtUrE${j}.test)
 done;
done;

for file in $DIR/CaPtUrE*.test; do
 echo "Average for $file:"
 COUNT=$((20 - $(cat $file | grep -wc "0")));
 cat $file | awk -F " " '{a+=$0}; END {printf "%d/%d=%d\n",a,NR-20,a/(NR-20)}' NR="$COUNT"
done;
rm -f $DIR/CaPtUrE*.test

# Viene attivato sul nodo 0 un "iperf -s"
# mentre sugli altri nodi viene lanciato il parallelo
# il comando "iperf -c node0 -P N" con N il numero di
# connessioni massime in parallelo che e' stato messo
# a 20.

## Su Mininet per lanciare i comandi in contemporanea e' stato usato:
# 	hosts = ["steffe1","steffe2", ... ,"steffe20"]
# 	for i in range(0,100):
# 		print(i)
# 		processes = []
# 		for host in hosts:
# 			command = 'echo -n "Runned on "; date; echo '+host+'; iperf -c 10.0.0.1 -t 5'
# 			p = multiprocessing.Process(target=run_command, args=(net.getNodeByName(host), command))
# 			p.start()
# 			processes.append(p)
# 		for p in processes:
# 			p.join()

## Sul cluster e' stato lanciato dal nodo steffe0 il comando:
#     for i in {1..100}; do
#         echo;
#         parallel -P20 --nonall --slf hosts.list 'echo -n Runned on; date; hostname; iperf -c steffe0 -t 5' >> output.o;
#     done
